# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# Copyright (c) 2024 Beijing RobotEra TECHNOLOGY CO.,LTD. All rights reserved.


from humanoid.envs.base.legged_robot_config import LeggedRobotCfg, LeggedRobotCfgPPO


class srt_humanoidCfg(LeggedRobotCfg):
    """
    Configuration class for the XBotL humanoid robot.
    """
    class env(LeggedRobotCfg.env):
        # change the observation dim
        frame_stack = 15
        c_frame_stack = 3
        num_single_obs = 47
        num_observations = int(frame_stack * num_single_obs)
        single_num_privileged_obs = 73
        num_privileged_obs = int(c_frame_stack * single_num_privileged_obs)
        num_actions = 12
        num_envs = 3060
        episode_length_s = 24     # episode length in seconds
        use_ref_actions = False   # speed up training by using reference actions

    class safety:
        # safety factors
        pos_limit = 1.0
        vel_limit = 1.0
        torque_limit = 0.85

    class asset(LeggedRobotCfg.asset):
        file = '{LEGGED_GYM_ROOT_DIR}/resources/SRT_Humanoid_robot/urdf/SRT_Humanoid_robot.urdf'

        name = "SRT_Humanoid_robot"
        foot_name = "6"
        knee_name = "4"

        terminate_after_contacts_on = ['base']
        penalize_contacts_on = ['base']
        self_collisions = 0  # 1 to disable, 0 to enable...bitwise filter
        flip_visual_attachments = False
        replace_cylinder_with_capsule = False# 机器人初始化时允许的最大地形等级（用于控制初始训练地形的难度）
        fix_base_link = False

    class terrain(LeggedRobotCfg.terrain):
        # mesh_type 定义地形的网格类型，原本是 'plane'，表示平面
        #mesh_type = 'plane'
        #改之前是上边的
        mesh_type = 'trimesh'
        # 是否使用课程学习（逐步增加地形难度），False 表示不使用
        curriculum = False
        # rough terrain only:
        # 是否测量机器人身体下方的高度信息（一般用于感知输入）
        measure_heights = False
        static_friction = 0.6       # 静摩擦系数
        dynamic_friction = 0.6      # 动摩擦系数
        terrain_length = 4.         #8 # 地域长度
        terrain_width = 4.          #8 # 地域宽度
        # 地形网格的行数，代表生成不同"难度等级"的地形层数
        num_rows = 4  #20 # number of terrain rows (levels)
        # 地形网格的列数，代表不同类型的地形
        num_cols = 4  # 20 # number of terrain cols (types)
        # 机器人初始化时允许的最大地形等级（用于控制初始训练地形的难度）
        max_init_terrain_level = 10  #10 # starting curriculum state
        # plane; obstacles; uniform; slope_up; slope_down, stair_up, stair_down

        #terrain_proportions = [0.2, 0.2, 0.4, 0.1, 0.1, 0, 0]
        terrain_proportions = [0, 0, 0, 0, 0, 1, 0]
        restitution = 0.

    class noise:
        add_noise = True
        noise_level = 0.6    # scales other values

        class noise_scales:
            dof_pos = 0.05
            dof_vel = 0.5
            ang_vel = 0.1
            lin_vel = 0.05
            quat = 0.03
            height_measurements = 0.1

    class init_state(LeggedRobotCfg.init_state):
        pos = [0.0, 0.0, 1.05]  # 略微增加初始高度

        default_joint_angles = {  # = target angles [rad] when action = 0.0
            'leg_l_joint1': 0.,
            'leg_l_joint2': 0.,
            'leg_l_joint3': -0.35,  # 增加膝盖弯曲
            'leg_l_joint4': 0.8,   # 增加膝盖弯曲
            'leg_l_joint5': -0.45,
            'leg_l_joint6': 0.,

            'leg_r_joint1': 0.,
            'leg_r_joint2': 0.,
            'leg_r_joint3': -0.35,  # 增加膝盖弯曲
            'leg_r_joint4': 0.8,   # 增加膝盖弯曲
            'leg_r_joint5': -0.45,
            'leg_r_joint6': 0.,
        }

    class control(LeggedRobotCfg.control):
        # PD Drive parameters:
        stiffness = {'1': 350.0, '2': 350.0, '3': 450.0,'4': 450.0, '5': 150.0,'6': 150.0}  # 增加关节刚度以提供更强的推力
        damping = {'1': 1, '2': 1, '3': 2, '4': 2, '5': 1, '6': 1}  # 增加关键关节的阻尼以稳定跳跃
        
        # action scale: target angle = actionScale * action + defaultAngle
        action_scale = 0.35  # 增加动作幅度以实现更大的跳跃运动
        # decimation: Number of control action updates @ sim DT per policy DT
        decimation = 10  # 100hz

    class sim(LeggedRobotCfg.sim):
        #码的目的是设置仿真参数，主要针对物理引擎配置。
        dt = 0.001  # 1000 Hz 设置仿真每帧的时间间隔 dt 为 0.001秒，也就是每秒进行 1000 次更新，频率为 1000Hz。此参数控制仿真精度和速度。
        substeps = 1 # 设置每一帧内的子步数为 1。子步数控制物理引擎在每个仿真步长内进行多少次模拟，增加子步数可以提高精度，但会增加计算量。
        up_axis = 1  # 0 is y, 1 is z

        class physx(LeggedRobotCfg.sim.physx):
            num_threads = 10 # 设置物理引擎使用的线程数为 10，意味着物理引擎的计算将在 10 个线程上并行运行，提高计算速度。
            solver_type = 1  # 0: pgs, 1: tgs 设置求解器的类型为 1（即 TGS，基于时间步长的广义的显式求解器）。
            #solver_type = 0 是 PGS（投影梯度法），用于处理约束优化问题，通常用于刚体动力学仿真。
            num_position_iterations = 4 #设置位置解算器的迭代次数为 4
            num_velocity_iterations = 0 #0 设置速度解算器的迭代次数为 0。速度迭代主要用于调整物体速度，以防止物体出现过大的速度差异
            contact_offset = 0.01  # [m] 设置碰撞偏移量为 0.01 米。这是一个容忍距离，用于避免物体在极小的接触力作用下发生重叠。此值决定了碰撞检测中物体的最小接触距离。
            rest_offset = 0.0   # [m] 设置碰撞偏移量为 0.01 米。这是一个容忍距离，用于避免物体在极小的接触力作用下发生重叠。此值决定了碰撞检测中物体的最小接触距离。
            bounce_threshold_velocity = 0.1  # [m/s] 设置反弹阈值速度为 0.1 米/秒。当物体碰撞时，如果相对速度低于此阈值，则不会发生反弹效果。
            max_depenetration_velocity = 1.0 # 设置最大去穿透速度为 1.0 米/秒。如果物体穿透其他物体且其速度超过此值，物理引擎会强制停止穿透并进行修正。
            max_gpu_contact_pairs = 2**23  # 2**24 -> needed for 8000 envs and more 设置 GPU 上最大允许的接触对数量为 2 的 23 次方（大约 8388608 个接触对）。这个参数影响到物理引擎可以处理的碰撞对的数量，适用于并行计算，尤其是在多个环境的仿真中。
            default_buffer_size_multiplier = 5  #设置默认缓冲区大小倍数为 5。这个参数用于物理引擎中的内存分配，决定了物理引擎缓冲区的初始大小，增大这个值有助于提高性能，但也会增加内存使用。
            # 0: never, 1: last sub-step, 2: all sub-steps (default=2)
            '''
            设置接触收集模式为 2，表示在所有子步中都会收集接触数据。
            contact_collection 控制物理引擎在仿真过程中如何处理接触信息，可以选择只在最后一个子步收集数据（1），或在每个子步收集数据（2）。
            '''
            contact_collection = 2

    class domain_rand:
        randomize_friction = True
        friction_range = [0.1, 2.0]
        randomize_base_mass = True
        added_mass_range = [-5., 5.]
        push_robots = True
        push_interval_s = 4
        max_push_vel_xy = 0.2
        max_push_ang_vel = 0.4
        # dynamic randomization
        action_delay = 0.5
        action_noise = 0.02

    class commands(LeggedRobotCfg.commands):
        # Vers: lin_vel_x, lin_vel_y, ang_vel_yaw, heading (in heading mode ang_vel_yaw is recomputed from heading error)
        num_commands = 4
        resampling_time = 8.  # time before command are changed[s]
        heading_command = True  # if true: compute ang vel command from heading error

        class ranges:
            lin_vel_x = [-0.3, 0.6]   # min max [m/s]
            lin_vel_y = [-0.3, 0.3]   # min max [m/s]
            ang_vel_yaw = [-0.3, 0.3] # min max [rad/s]
            heading = [-3.14, 3.14]

    class rewards:
        base_height_target = 1.0
        min_dist = 0.2
        max_dist = 0.5
        # put some settings here for LLM parameter tuning
        target_joint_pos_scale = 0.3    # 0.17 # rad
        target_feet_height = 0.40        # 修改为0.40 m，增加跳跃高度
        cycle_time = 1.0                # 增加周期时间从0.64到1.0秒，使跳跃动作更慢更协调
        # if true negative total rewards are clipped at zero (avoids early termination problems)
        only_positive_rewards = True
        # tracking reward = exp(error*sigma)
        tracking_sigma = 5
        max_contact_force = 700  # Forces above this value are penalized

        class scales:
            # reference motion tracking === 参考运动跟踪 ===
            joint_pos = 2.0             #1.6 # 关节位置跟踪奖励系数（鼓励关节跟踪目标位置）
            feet_clearance = 8.0         # 增加到8.0，强化脚部离地高度奖励
            feet_contact_number = 0.8   # 降低到0.8，减少对接触次数的强调
            # gait
            feet_air_time = 6.0          # 增加到6.0，鼓励更长的空中时间
            foot_slip = -0.05           # 脚部滑动惩罚系数（负值表示惩罚）
            feet_distance = 0.2         # 双脚间距奖励（保持适当横向距离）
            knee_distance = 0.3         #0.2 # 膝盖间距奖励（防止腿部碰撞）
            # contact   === 接触控制 ===
            feet_contact_forces = -0.01 # 脚部接触力惩罚（避免过大冲击力）
            # vel tracking  === 速度跟踪 ===
            tracking_lin_vel = 1.2 # 1.2    # 线性速度跟踪奖励（X,Y方向移动）
            tracking_ang_vel = 1.1          # 角速度跟踪奖励（绕Z轴旋转）
            vel_mismatch_exp = 0.5  # lin_z; ang x,y # 速度不匹配指数（调整误差敏感度）
            low_speed = 0.2                 # 低速状态阈值（低于此速度时触发特殊处理）
            track_vel_hard = 0.5            # 硬性速度跟踪权重（严格速度跟踪的额外奖励）
            # base pos  === 本体姿态控制 ===
            default_joint_pos = 0.5         # 默认关节位置奖励（保持中立位）
            orientation = 1.                # 本体姿态奖励（保持身体水平）
            base_height = 0.2               # 本体高度奖励（维持理想高度）
            base_acc = 0.2                  # 本体加速度惩罚（防止剧烈运动）
            # energy    === 能量效率 ===
            action_smoothness = -0.002      # 动作平滑度惩罚（抑制突变）
            torques = -1e-5                 # 关节扭矩惩罚（降低能耗）
            dof_vel = -5e-4                 # 关节速度惩罚（抑制高速运动）
            dof_acc = -1e-7                 # 关节加速度惩罚（减少急加速）
            collision = -1.                 # 碰撞惩罚（防止与环境碰撞）

    class normalization:
        class obs_scales:
            lin_vel = 2.
            ang_vel = 1.
            dof_pos = 1.
            dof_vel = 0.05
            quat = 1.
            height_measurements = 5.0
        clip_observations = 18.
        clip_actions = 18.


class srt_humanoidCfgPPO(LeggedRobotCfgPPO):
    seed = 5
    runner_class_name = 'OnPolicyRunner'   # DWLOnPolicyRunner

    class policy:
        init_noise_std = 1.0
        actor_hidden_dims = [512, 256, 128]
        critic_hidden_dims = [768, 256, 128]

    class algorithm(LeggedRobotCfgPPO.algorithm):
        entropy_coef = 0.001
        learning_rate = 1e-5
        num_learning_epochs = 2
        gamma = 0.994
        lam = 0.9
        num_mini_batches = 4

    class runner:
        policy_class_name = 'ActorCritic'
        algorithm_class_name = 'PPO'
        num_steps_per_env = 60  # per iteration
        max_iterations = 3001  # number of policy updates

        # logging
        save_interval = 100  # Please check for potential savings every `save_interval` iterations.
        experiment_name = 'srt_humanoid_ppo'
        run_name = ''
        # Load and resume
        resume = False
        load_run = -1  # -1 = last run ##'/home/lxy/humanoid-gym/logs/srt_humanoid_ppo/Feb11_11-26-14_v1'
        checkpoint = -1  # -1 = last saved model ## '2100'
        resume_path = None  # updated from load_run and chkpt
